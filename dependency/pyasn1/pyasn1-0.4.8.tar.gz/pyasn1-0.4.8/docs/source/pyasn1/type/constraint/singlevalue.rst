
.. _constrain.SingleValueConstraint:

.. |Constraint| replace:: SingleValueConstraint

Single value constraint
-----------------------

.. autoclass:: pyasn1.type.constraint.SingleValueConstraint
   :members:
