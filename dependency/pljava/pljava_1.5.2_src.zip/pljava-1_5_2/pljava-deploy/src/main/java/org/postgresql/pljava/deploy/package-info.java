/**
 * <p>Note: this package is obsolescent as of PL/Java 1.5.0.
 * See <a href='{@docRoot}/../../install/install.html'>Installing PL/Java</a>
 * for the current installation instructions that do not require this code.
 * This subproject will eventually be outdated and removed.
 * <p>
 * One approach to completing the SQL steps of PL/Java installation; will build
 * a normal, standalone Java app to connect to the database over a vanilla
 * JDBC connection and install, remove, or reinstall the necessary objects.
 * See {@link org.postgresql.pljava.deploy.Deployer Deployer} for usage.
 * @author Thomas Hallgren
 */
package org.postgresql.pljava.deploy;
