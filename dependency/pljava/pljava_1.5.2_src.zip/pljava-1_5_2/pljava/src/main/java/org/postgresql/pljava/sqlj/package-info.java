/**
 * PL/Java's classloading from the jars managed by
 * {@link org.postgresql.pljava.management.Commands#installJar(String,String,
boolean) installJar}.
 * @author Thomas Hallgren
 */
package org.postgresql.pljava.sqlj;
