/**
 * Implementation of the functions specified by the SQL/JRT spec in the
 * <code>sqlj</code> schema, and related PL/Java-specific ones. See
 * {@link org.postgresql.pljava.management.Commands Commands} for their
 * descriptions.
 * @author Thomas Hallgren
 */
package org.postgresql.pljava.management;
