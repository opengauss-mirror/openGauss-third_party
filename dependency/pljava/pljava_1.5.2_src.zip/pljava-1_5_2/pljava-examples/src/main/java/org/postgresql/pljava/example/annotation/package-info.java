/**
 * The first examples that were converted to test the <a href=
"{@docRoot}/../../pljava-api/apidocs/org/postgresql/pljava/annotation/package-summary.html"
>annotation-driven SQL generator</a> instead of using hand-written SQL
 * deployment code.
 * @author Thomas Hallgren
 * @author Chapman Flack
 */
package org.postgresql.pljava.example.annotation;
