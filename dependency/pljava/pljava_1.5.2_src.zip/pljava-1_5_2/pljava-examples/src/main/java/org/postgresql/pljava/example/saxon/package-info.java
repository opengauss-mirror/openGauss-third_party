/**
 * Examples using the Saxon-HE library for XML processing, and requiring Java 8.
 * Only built if {@code -Psaxon-examples} is given on the {@code mvn} command
 * line (which will also cause Saxon-HE to be downloaded).
 * @author Chapman Flack
 */
package org.postgresql.pljava.example.saxon;
