/**
 * The examples that have been around the longest, and are deployed using
 * hand-written SQL deployment code (see {@code src/main/resources/deployment}),
 * not having been reworked to use annotations yet.
 * @author Thomas Hallgren
 */
package org.postgresql.pljava.example;
