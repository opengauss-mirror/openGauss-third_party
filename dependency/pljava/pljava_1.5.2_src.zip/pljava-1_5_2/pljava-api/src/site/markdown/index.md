## About PL/Java API

The `pljava-api` subproject builds the PL/Java published API classes; this
machine-generated page is a project summary for developers of PL/Java.

If you arrived here from a search for PL/Java API, you probably want
[the user guide][ug], or [the API documentation][tad].

[ug]: ../use/use.html
[tad]: apidocs/index.html
