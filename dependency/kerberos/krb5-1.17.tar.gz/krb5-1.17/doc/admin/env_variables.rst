Environment variables
=====================

This content has moved to :ref:`kerberos(7)`.
